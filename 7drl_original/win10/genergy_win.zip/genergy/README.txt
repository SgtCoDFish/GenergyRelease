Info:

this version is tested on Cygwin only, because windows + curses is a strange beast.

If you don't have cygwin you might need to install it so you can run genergy:

https://cygwin.com/install.html

Honestly, if you're even trying this, mad props to you. I don't expect anyone to really ready this :P